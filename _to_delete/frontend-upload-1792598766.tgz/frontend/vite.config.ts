import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'
import { fileURLToPath, URL } from 'node:url'

export default defineConfig({
  plugins: [react(), tailwindcss()],
  resolve: { alias: { '@': fileURLToPath(new URL('./src', import.meta.url)) } },
  server: {
    // One origin for the browser: cookies and the backend's CSRF/origin checks then work without extra CORS.
    proxy: { '/api': { target: 'http://localhost:4000', changeOrigin: false } },
  },
})
