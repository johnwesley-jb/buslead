# Buslead frontend (preview build)

React + TypeScript + Vite + Tailwind CSS v4 + TanStack Query + React Hook Form + Zod.

This build runs entirely on **simulated data**. There is no backend, database, Vapi or Google
connection yet. Everything the UI reads and writes goes through `src/mock/api.ts`, which adds
latency, validates like the real API will, and saves to `localStorage`.

## Run it

```bash
npm install
npm run dev        # http://localhost:5173
npm run build      # type-checks, then builds to dist/
```

Sign in with `admin@buslead.test` or `agent@buslead.test`, password `buslead-demo`.
Admins can delete leads, change scheduling rules and connect the calendar. Agents cannot.
Profile & security has a "Reset preview data" button.

## What is simulated

| Area | Behavior in this preview |
| --- | --- |
| Leads, calls, appointments | 42 generated leads covering every scenario: caller booked, caller accepted an alternative, caller hung up (automatic assignment), calendar failure (needs a time), pending reservation, completed, cancelled, manual. |
| Availability | `src/mock/scheduler.ts` applies business hours, duration, buffer, minimum notice, horizon, holidays, internal appointments and external "busy" events. Booking re-checks the slot and fails with "no longer available" instead of faking success. |
| Calendar connection | Connect/disconnect/sync are simulated. Disconnecting blocks new bookings. |
| Recording playback | A clock walks through the call so seeking and transcript sync work. No audio file exists. Swap for an `<audio>` element pointed at the authorized recording endpoint. |
| Auth | Two demo users. The real build uses server sessions. |

## Swapping in the real backend

1. Replace the functions in `src/mock/api.ts` with `fetch` calls. Keep the signatures; `src/hooks/queries.ts` and the pages depend only on them.
2. Move `src/lib/types.ts` into a shared package used by both apps.
3. Delete `src/mock/seed.ts` and the demo account hint on the login page.

## Structure

```
src/
  auth/          session context
  components/    ui kit, shell, call player, schedule dialog
  hooks/         TanStack Query hooks (one place for cache keys and invalidation)
  lib/           types, date helpers, formatting
  mock/          simulated API, seed data, slot engine
  pages/         one file per screen
```
